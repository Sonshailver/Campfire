extends CharacterBody2D
@export var particulas = Node
@export var animacion = Node
var SPEED = 500.0
var ejecutando = true

@onready var timer: Timer = $Timer
@onready var label: Label = $CanvasLayer/Label
@export var sonido = Node
@onready var game_over_scene = preload("res://Levels/game_over.tscn")

var tiempo := 0

func _ready() -> void:
	add_to_group("player")
	

func _on_timer_timeout():
	tiempo += 1
	label.text = "Tiempo: " + str(tiempo)
func _physics_process(delta: float) -> void:
	# Add the gravity.
	
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Handle jump.

	if Input.is_action_just_pressed("ui_accept"):
		var SPEED = 1000.0
		

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var directionx := Input.get_axis("ui_left", "ui_right")
	if directionx:
		velocity.x = directionx * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
		
	var directiony := Input.get_axis("ui_up", "ui_down")
	if directiony:
		velocity.y = directiony * SPEED
	else:
		velocity.y = move_toward(velocity.x, 0, SPEED)
		
	if Input.is_action_just_pressed("ui_left"):
		animacion.flip_h = false
		animacion.play("swin")
	elif Input.is_action_just_pressed("ui_right"):
		animacion.flip_h = true
		animacion.play("swin")
		particulas.emitting = true
	else:
		animacion.play("idle")

	move_and_slide()
	
	

func _on_area_2d_body_entered(body):
	if body.is_in_group("enemy"):
		game_over()
		sonido.play()
		animacion.play("die")
	

func detener():
	ejecutando = false
	


func game_over():

	var instance = game_over_scene.instantiate()
	get_tree().current_scene.add_child(instance)
