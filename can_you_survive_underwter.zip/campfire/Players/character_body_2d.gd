extends CharacterBody2D
@export var animacion = Node
@export var velocidad: float= 500.0
@export var max_velocidad: float= 1000.0
@export var acceleration_rate := 10
var retry: PackedScene
var current_speed
var player = null
func _ready() -> void:
	player = get_tree().get_first_node_in_group("player")
	current_speed = velocidad
	add_to_group("enemy")

func _physics_process(delta: float) -> void:
	current_speed += acceleration_rate * delta
	current_speed = min(current_speed, max_velocidad)
	if player:
		var direccion = (player.global_position - global_position).normalized()
		velocity = direccion * velocidad
		move_and_slide()
		animacion.play("run")
		
		
	if is_in_group("player"):
		game_over()
func game_over():
	get_tree().change_scene_to_packed(retry)


		
