extends Control
class_name HUD





var tiempo_transcurrido: float = 0.0
@onready var label = $Label2 # Asegúrate de que el nombre coincida con tu nodo

func _process(delta):
	# 1. Acumulamos el tiempo real en segundos
	tiempo_transcurrido += delta
	
	# 2. Formateamos el texto para que se vea limpio (ej. 12.55)
	# Usamos str() para convertir el número a texto
	label.text = str(snapped(tiempo_transcurrido, 0.01))
