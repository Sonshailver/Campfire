extends Control

@export var sonido = Node
@export var level = PackedScene
func _ready() -> void:
	# Conectar la señal del botón si no lo hiciste en el editor
	pass
	

func _on_button_pressed():
	get_tree().change_scene_to_packed(level)
	sonido.play()
	pass # Replace with function body.


func _on_button_2_pressed():
	get_tree().quit()
	pass # Replace with function body.
