extends Control

@export var retry = PackedScene
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass




func _on_button_pressed() -> void:
	
	get_tree().change_scene_to_packed(retry)
	get_tree().reload_current_scene()
	pass # Replace with function body.
